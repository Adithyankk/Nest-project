export interface TokenInput {
    email: string;
    userId: string;
  }